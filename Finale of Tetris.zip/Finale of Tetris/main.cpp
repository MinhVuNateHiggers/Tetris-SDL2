#include "game.h"
// HOPE THIS SHIT RUNS

int main(int argc, char* argv[])
{
	stateLoop();
	return 0;
}

