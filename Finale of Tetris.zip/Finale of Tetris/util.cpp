#include "util.h"
#include "Tetromino.h"
#include "SDL_image.h"
#include <iostream>
using namespace std;
// Constructor
Util::Util()
{
	window = NULL;
	renderer = NULL;
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		cout << "There was an error while initializing SDL. \n" << SDL_GetError();
	}
	else
	{
		window = SDL_CreateWindow("Cheap Tetris Spin-off", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
		renderer = SDL_CreateRenderer(window, -1, 0);
		SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
		SDL_RenderClear(renderer);
		SDL_RenderPresent(renderer);
		if (window == NULL)
		{
			cout << "There was an error while creating the window.\n" << SDL_GetError();
		}
	}

	if (TTF_Init() < 0)
	{
		cout << "There was a TTF error. \n" << TTF_GetError();
	}

	rect.x = rect.y = rect.w = rect.h = 0;
	texture = NULL;
	textSurface = NULL;
	font = TTF_OpenFont("pixel.ttf", 64);
	textColor = { 255, 255, 255, 255 };
}

// Cap nhat renderer
void Util::drawUpdate()
{
	SDL_RenderPresent(renderer);
}

// Ve cac khoi hinh
void Util::drawShape(Tetromino tetro, int currentX, int currentY, int currentRotation)
{
	// Lay tham so can thiet
	string currentTetro = tetro.currTetro();
	int currentNum = tetro.currentTetro;
	int index = tetro.currIndex();

    // Thiet lap mau ve cho renderer
	SDL_SetRenderDrawColor(renderer, pieceColors[currentNum].r, pieceColors[currentNum].g, pieceColors[currentNum].b, pieceColors[currentNum].a);
	for (int x = 0; x < index; x++)
		for (int y = 0; y < index; y++)
			if (currentTetro[tetro.rotate(x, y, currentRotation)] == 'X')
			{
				rect.x = (currentX + x) * GRID_SIZE;
				rect.y = (currentY + y) * GRID_SIZE + TOP_OFFSET;
				rect.w = rect.h = GRID_SIZE;
				SDL_RenderFillRect(renderer, &rect);
			}
}

// Ve bang choi
void Util::drawBoard(Board board)
{
	for (int x = 0; x < BOARD_WIDTH; x++)
		for (int y = 0; y < BOARD_HEIGHT; y++)
		{
			// Duyet va lay gia tri trong bang choi ( co the la o trong hoac la khoi hinh )
			// Ve mau dua tren gia tri cua bang choi
			int index = board.returnIndexAt(x, y);
			SDL_SetRenderDrawColor(renderer, boardColors[index].r, boardColors[index].g, boardColors[index].b, boardColors[index].a);

			rect.x = x * GRID_SIZE;
			rect.y = y * GRID_SIZE + TOP_OFFSET;
			rect.w = rect.h = GRID_SIZE;
			SDL_RenderFillRect(renderer, &rect);
		}
}

// Ve khoi hinh tiep theo
void Util::drawNextP(int nextTetro)
{
	// Lay tham so can thiet
	Tetromino tetro;
	tetro.currentTetro = nextTetro;
	string nextPiece = tetro.currTetro();
	int index = tetro.currIndex();

	SDL_SetRenderDrawColor(renderer, pieceColors[nextTetro].r, pieceColors[nextTetro].g, pieceColors[nextTetro].b, pieceColors[nextTetro].a);

	for (int x = 0; x < index; x++)
		for (int y = 0; y < index; y++)
			if (nextPiece[tetro.rotate(x, y, 0)] == 'X')
			{
			    // Ve tren goc ben phai cua man hinh
				rect.x = (x + BOARD_WIDTH) * GRID_SIZE - 10;
				if (nextTetro == 1)
                {
                    rect.y = (y * GRID_SIZE) + TOP_OFFSET - 30;
                }

				else
                {
                    rect.y = (y * GRID_SIZE) + TOP_OFFSET;
				}
				rect.w = rect.h = GRID_SIZE;
				SDL_RenderFillRect(renderer, &rect);
			}
}

// Ve hinh dang khoi hinh dang luu
void Util::drawHeldP(int heldPiece)
{
	// Lay tham so can thiet
	Tetromino tetro;
	tetro.currentTetro = heldPiece;
	string nextPiece = tetro.currTetro();
	int index = tetro.currIndex();

	SDL_SetRenderDrawColor(renderer, pieceColors[heldPiece].r, pieceColors[heldPiece].g, pieceColors[heldPiece].b, pieceColors[heldPiece].a);
	for (int x = 0; x < index; x++)
		for (int y = 0; y < index; y++)
			if (nextPiece[tetro.rotate(x, y, 0)] == 'X')
			{
			    // Ve ben duoi o Next Piece
				rect.x = (x + BOARD_WIDTH) * GRID_SIZE - 10;
				if (heldPiece == 1)
                {
                    rect.y = (y * GRID_SIZE) + TOP_OFFSET * 2.5 - 30;
                }

				else
                {
                    rect.y = (y * GRID_SIZE) + TOP_OFFSET * 2.5;
				}
				rect.w = rect.h = GRID_SIZE;
				SDL_RenderFillRect(renderer, &rect);
			}
}


// Ve phan ben tren cua man hinh
void Util::drawTop()
{
	SDL_SetRenderDrawColor(renderer, border.r, border.g, border.b, border.a);
	for (int x = 0; x < SCREEN_WIDTH / GRID_SIZE; x++)
		for (int y = 0; y < TOP_OFFSET / GRID_SIZE; y++)
		{
			if (x * GRID_SIZE > 10 || y * GRID_SIZE > 4)
			{
				rect.x = x * GRID_SIZE;
				rect.y = y * GRID_SIZE;
				rect.w = rect.h = GRID_SIZE;
				SDL_RenderFillRect(renderer, &rect);
			}
		}
}

// Ve bong cua khoi hinh
void Util::drawShadow(Tetromino tetro, Board board, int currentX, int currentY, int currentRotation)
{
	int index = tetro.currIndex();
	string currentTetro = tetro.currTetro();
	int possibleY = currentY;

	SDL_SetRenderDrawColor(renderer, black.r, black.g, black.b, black.a);
	while (checkCollision(tetro, board, currentRotation, currentX, possibleY + 1))
		possibleY++;
	for (int x = 0; x < index; x++)
		for (int y = 0; y < index; y++)
			if (currentTetro[tetro.rotate(x, y, currentRotation)] == 'X')
			{
				rect.x = (currentX + x) * GRID_SIZE;
				rect.y = (possibleY + y) * GRID_SIZE + TOP_OFFSET;
				rect.w = rect.h = GRID_SIZE;
				SDL_RenderDrawRect(renderer, &rect);
			}
}

// Viet len tren man hinh tai vi tri cu the
void Util::writeText(string text, int x, int y, int w, int h)
{
	textSurface = TTF_RenderText_Solid(font, text.c_str(), textColor);
	texture = SDL_CreateTextureFromSurface(renderer, textSurface);
	rect.x = x;
	rect.y = y;
	rect.h = h;
	rect.w = w;
	SDL_RenderCopy(renderer, texture, NULL, &rect);
	SDL_FreeSurface(textSurface);
	SDL_DestroyTexture(texture);
}

// Xoa man hinh va thiet lap lai ve mau xam
void Util::clear()
{
	SDL_SetRenderDrawColor(renderer, border.r, border.g, border.b, border.a);
	SDL_RenderClear(renderer);
}

// Giai phong tai nguyen
void Util::destroy()
{
	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);
}


