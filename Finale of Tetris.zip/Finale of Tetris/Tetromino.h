#pragma once
#include <string>
using namespace std;
class Tetromino
{
private :
	string allTetros[7];
public:
	int currentTetro;
	Tetromino();
	string currTetro();
	string getTetro(int tetroNum);
	int currIndex();
	int maxIndex(int currentTetro);
	int rotate(int x, int y, int currentRotation);
};


