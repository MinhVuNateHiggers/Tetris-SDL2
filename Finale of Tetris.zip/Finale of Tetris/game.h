#pragma once
#include "util.h"
#include <SDL.h>
#include <SDL_mixer.h>
#include <bits/stdc++.h>
using namespace std;

enum class GameState {START_MENU, IN_GAME, GAME_OVER, QUIT};

bool checkCollision(Tetromino tetro, Board board, int currentRotation, int xPos, int yPos);
bool hardDrop(Tetromino tetro, Board board, int currentRotation, int currentX, int& currentY);
void lineCheck(Board board, vector<int>& lines, int& lineCount, int& speed, int& level, int maxIndex, int currentY);
void removeLines(Board board, vector<int>& storeLine);
void stateLoop();
