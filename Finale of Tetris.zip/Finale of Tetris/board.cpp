#include "board.h"
using namespace std;
// Constructor
//Su dung mang 1 chieu de mo phong mang 2 chieu
//Cap phat bo nho cho con tro voi kich thuoc bang tong so o vuong trong man choi
//Anh xa x,y vao chi so 1 chieu cua mang
Board::Board()
{
	playField = new unsigned char[BOARD_WIDTH * BOARD_HEIGHT];
	for (int x = 0; x < BOARD_WIDTH; x++)
		for (int y = 0; y < BOARD_HEIGHT; y++)
			// Sau khi duyet qua cac o trong board, dat cac hang o bien voi gia tri = 8, cac o trong = 0
			playField[(y * BOARD_WIDTH) + x] = (x == 0 || x == BOARD_WIDTH - 1 || y == BOARD_HEIGHT - 1) ? 8 : 0;
}

// Them 1 khoi hinh vao bang choi
void Board::addNewPiece(Tetromino tetro, int currentRotation, int currentX, int currentY)
{
	// Lay cac tham so can thiet
	string thisTetromino = tetro.currTetro();
	int temp = tetro.currIndex(); // gia tri la 4 hoac 3

	for (int x = 0; x < temp; x++)
		for (int y = 0; y < temp; y++)
			if (thisTetromino[tetro.rotate(x, y, currentRotation)] == 'X')
			{
				playField[(currentY + y) * BOARD_WIDTH + (currentX + x)] = tetro.currentTetro + 1;
			}
            // Sau khi duyet xem cac o vuong co ki tu 'X' hay khong, se them gia tri cua khoi Tetromino vao bang choi dua vao vi tri hien tai, goc quay hien tai
            // +1 vi chi so cua cac khoi tetromino bat dau tu 0, tranh xung dot voi cac o trong
            // VD : Khi them khoi hinh chu I co gia tri = 0 vao bang se co gia tri la 1 tai vi tri tuong ung
}

// Tra ve gia tri tai 1 o tren bang choi
int Board::returnIndexAt(int x, int y)
{
	return playField[x + (BOARD_WIDTH * y)];
}

// Dat cac gia tri tai 1 o thanh gia tri tuong ung voi 1 hang = 9
void Board::setLine(int x, int y)
{
	playField[(y * BOARD_WIDTH) + x] = 9;

}

// Dat cac gia tri o cu the thanh gia tri cua cac o ben tren cua no
void Board::setAbove(int x, int y)
{
	playField[y * BOARD_WIDTH + x] = playField[(y - 1) * BOARD_WIDTH + x];
}

// Dat cac gia tri tai vi tri x trong bang choi thanh 0 ( dung de xoa cac hang trong bang )
void Board::EmptyBoard(int x)
{
	playField[x] = 0;
}


