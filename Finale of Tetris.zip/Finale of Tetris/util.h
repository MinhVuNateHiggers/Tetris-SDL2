#pragma once
#include "colors.h"
#include "Tetromino.h"
#include "board.h"
#include "game.h"
#include "SDL.h"
#include "SDL_mixer.h"
#include "SDL_ttf.h"
using namespace std;

const int GRID_SIZE = 30; // Kich thuoc o
const int TOP_OFFSET = 120; // Khoang cach tu dinh cua so den board
const int SCREEN_HEIGHT = 750;
const int SCREEN_WIDTH = 500;

struct Util
{
	SDL_Window* window;
	SDL_Renderer* renderer;
	SDL_Rect rect;
	SDL_Texture* texture;
	SDL_Surface* textSurface;
	TTF_Font* font;
	SDL_Color textColor;
public:
	Util();
	void UpdateRender();
	void drawPiece(Tetromino tetro, int currentX, int currentY, int currentRotation);
	void drawBoard(Board board);
	void drawHeldP(int heldPiece);
	void drawNextP(int nextNum);
	void drawTop();
	void drawShadow(Tetromino tetro, Board board, int currentX, int currentY, int currentRotation);
	void writeText(string text, int x, int y, int w, int h);
	void soundEffect(const char* path);
	void BGM();
	void clear();
	void destroy();
};


