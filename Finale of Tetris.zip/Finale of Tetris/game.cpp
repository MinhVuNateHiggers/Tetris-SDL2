#include "game.h"
#include "util.h"
using namespace std;

bool checkCollision(Tetromino tetro, Board board, int currentRotation, int xPos, int yPos)
{
	int index = tetro.currIndex();
	string currentTetro = tetro.currTetro();

	for (int x = 0; x < index; x++)
		for (int y = 0; y < index; y++)
		{
			int tetroIndex = tetro.rotate(x, y, currentRotation); // Gia tri o sau khi xoay
			int fieldIndex = board.returnIndexAt(xPos + x, yPos + y); // Gia tri cua o tren bang choi tai vi tri cu the
			if (xPos + x >= 0 && xPos + x < BOARD_WIDTH)
			{
				if (yPos + y >= 0 && yPos + y < BOARD_HEIGHT)
				{
					if (currentTetro[tetroIndex] == 'X' && fieldIndex != 0)
						return false;
				}
			}
		}
	return true;
}

bool hardDrop(Tetromino tetro, Board board, int currentRotation, int currentX, int& currentY)
{
	while (checkCollision(tetro, board, currentRotation, currentX, currentY + 1))
		currentY++;
	return true;
}

void lineCheck(Board board, vector<int> &lines, int &lineCount, int& speed, int& level, int Index, int currentY)
{
	for (int y = 0; y < Index; y++)
	{
		if (currentY + y < BOARD_HEIGHT - 1)
		{
			bool line = true;
			for (int x = 1; x < BOARD_WIDTH - 1; x++)
			{
				int fieldIndex = board.returnIndexAt(x, y + currentY);
				line &= (fieldIndex) != 0;
			}
			if (line)
			{
				for (int x = 1; x < BOARD_WIDTH - 1; x++)
				{
					board.setLine(x, y + currentY);
				}
				lineCount++;
				if (lineCount > 0 && lineCount % 10 == 0 && speed > 1)
				{
					speed--;
					level = 21 - speed;
				}
				lines.push_back(currentY + y);
			}
		}
	}
}

void removeLines(Board board, vector<int>& storeLine)
{
	for (auto& v : storeLine)
	{
		for (int x = 1; x < BOARD_WIDTH - 1; x++)
		{
			for (int y = v; y > 0; y--)
			{
				board.setAbove(x, y);
			}
			board.EmptyBoard(x);
		}
		storeLine.clear();
	}
}
