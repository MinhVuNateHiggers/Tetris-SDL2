#include "game.h"
using namespace std;

// Kiem tra va cham xem
bool checkCollision(Tetromino tetro, Board board, int currentRotation, int xPos, int yPos)
{
	// Lay tham so can thiet
	int index = tetro.currIndex();
	string currentTetro = tetro.currTetro();

	for (int x = 0; x < index; x++)
		for (int y = 0; y < index; y++)
		{
			int tetroIndex = tetro.rotate(x, y, currentRotation); // Gia tri o sau khi xoay
			int fieldIndex = board.returnIndexAt(xPos + x, yPos + y); // Gia tri cua o tren bang choi tai vi tri cu the
			if (xPos + x >= 0 && xPos + x < BOARD_WIDTH)
			{
				if (yPos + y >= 0 && yPos + y < BOARD_HEIGHT)
				{
					if (currentTetro[tetroIndex] == 'X' && fieldIndex != 0)
						return false;
				}
			}
		}
	return true;
}

// "Hard drop" cho 1 manh xuong vi tri sau nhat
bool hardDrop(Tetromino tetro, Board board, int currentRotation, int currentX, int& currentY)
{
	while (checkCollision(tetro, board, currentRotation, currentX, currentY + 1))
		currentY++;
	return true;
}

// Kiem tra xem da co hang hoan chinh chua va them no vao vector lines
void lineCheck(Board board, vector<int> &lines, int &lineCount, int& speed, int& level, int Index, int currentY)
{
	for (int y = 0; y < Index; y++)
	{
		if (currentY + y < BOARD_HEIGHT - 1)
		{
			bool line = true;
			for (int x = 1; x < BOARD_WIDTH - 1; x++)
			{
				int fieldIndex = board.returnIndexAt(x, y + currentY);
				line &= (fieldIndex) != 0;
			}
			if (line)
			{
				for (int x = 1; x < BOARD_WIDTH - 1; x++)
				{
					board.setLine(x, y + currentY);
				}
				lineCount++;
				// Nang cao do kho tro choi voi moi hang giai duoc ( tuy chinh do kho thi hay thay doi lineCount )
				if (lineCount > 0 && lineCount % 10 == 0 && speed > 1)
				{
					speed--;
					level = 21 - speed;
				}
				lines.push_back(currentY + y);
			}
		}
	}
}

// Xoa hang ra khoi mang choi
void removeLines(Board board, vector<int>& storeLine)
{
	for (auto& v : storeLine)
	{
		for (int x = 1; x < BOARD_WIDTH - 1; x++)
		{
			for (int y = v; y > 0; y--)
			{
				board.setAbove(x, y);
			}
			board.EmptyBoard(x);
		}
		storeLine.clear();
	}
}

GameState currState;
bool muted;
int finalScore;

// Vong lap chinh cua game
void gameLoop(Util util)
{
	Tetromino tetro;
	Board board;

	// Game logic
	bool gameOver = false;
	bool moveDown = false;
	bool alreadyHeld = false;

	// Tham so can thiet cua tro choi
	int currentX = (BOARD_WIDTH / 2) - 2;
	int currentY = 0;
	int currentRotation = 0;
	int nextTetro;
	int heldPiece = 8;
	int speed = 20;
	int speedCounter = 0;
	int level = 21 - speed;
	int score = 0;
	int lineCount = 0;

	// Diem va level
	string scoreText = "Score: " + to_string(score);
	string levelText = "Level: " + to_string(level);

	// Vector xu li hang
	vector<int> storeLine;

	// Random number generation
	time_t t;
    srand((unsigned)time(&t));
	tetro.currentTetro = rand() % 7;
	nextTetro = rand() % 7;

	// Keyboard Event
	SDL_Event e;

	// Music
	Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);
	Mix_Music* theme = Mix_LoadMUS("TetrisTheme.wav");
	Mix_PlayMusic(theme, -1);
	Mix_VolumeMusic(MIX_MAX_VOLUME / 8);

	while (!gameOver)
	{
	    // Kiem soat toc do di chuyen cua cac khoi hinh
		this_thread::sleep_for(chrono::milliseconds(50));
		speedCounter++;
		moveDown = (speedCounter == speed);

		// Input tu ban phim
		while (SDL_PollEvent(&e) != 0)
		{
			// An phim esc
			if (e.type == SDL_QUIT)
			{
				gameOver = true;
				currState = GameState::QUIT;
			}
            // Xu li su kien ban phim
			if (e.type == SDL_KEYDOWN)
			{
				switch (e.key.keysym.sym)
				{
				case SDLK_UP:
					if (checkCollision(tetro, board, currentRotation + 1, currentX, currentY))
					{
						currentRotation++;
					}
					break;

				case SDLK_DOWN:
					if (checkCollision(tetro, board, currentRotation, currentX, currentY + 1))
					{
						currentY++;
					}
					break;

				case SDLK_RIGHT:
					if (checkCollision(tetro, board, currentRotation, currentX + 1, currentY))
					{
						currentX++;
					}
					break;

				case SDLK_LEFT:
					if (checkCollision(tetro, board, currentRotation, currentX - 1, currentY))
					{
						currentX--;
					}
					break;

				case SDLK_SPACE:
					moveDown = hardDrop(tetro, board, currentRotation, currentX, currentY);
					break;

				case SDLK_m:
					if (muted) {
						Mix_VolumeMusic(MIX_MAX_VOLUME / 8);
						muted = false;
					}
					else {
						Mix_VolumeMusic(0);
						muted = true;
					}
					break;

				case SDLK_c:
					if (!alreadyHeld)
					{
						if (heldPiece == 8)
						{
							heldPiece = tetro.currentTetro;
							tetro.currentTetro = nextTetro;
							nextTetro = rand() % 7;
						}
						else
						{
							int tempPiece = tetro.currentTetro;
							tetro.currentTetro = heldPiece;
							heldPiece = tempPiece;
						}
						currentX = (BOARD_WIDTH / 2) - 2;
						currentY = 0;
						currentRotation = 0;
						alreadyHeld = true;
					}
					break;

				case SDLK_ESCAPE:
					gameOver = true;
					break;
				}
			}
		}

		// Xu li viec di chuyen xuong 1 khoi hinh
		if (moveDown)
		{
			speedCounter = 0;

			if (checkCollision(tetro, board, currentRotation, currentX, currentY + 1))
			{
				currentY++;
			}
			else
			{
 				board.addNewPiece(tetro, currentRotation, currentX, currentY);

				lineCheck(board, storeLine, lineCount, speed, level, tetro.currIndex(), currentY);
                // Score
				if (!storeLine.empty())
                    score += (1 << storeLine.size()) * 100;

				// Xoa hang
				if (!storeLine.empty())
				{
					// Animation xoa hang
					util.drawBoard(board);
					util.drawUpdate();
					this_thread::sleep_for(chrono::milliseconds(100));
					removeLines(board, storeLine);
				}

				// Lay khoi hinh tiep theo
				currentX = (BOARD_WIDTH / 2) - 2;
				currentRotation = 0;
				tetro.currentTetro = nextTetro;
				currentY = (tetro.currIndex() == 4) ? -1 : 0;
				nextTetro = rand() % 7;

				// Neu da cham dinh --> game over
				gameOver = !checkCollision(tetro, board, currentRotation, currentX, currentY);

				alreadyHeld = false;
			}
		}

		// Ve man hinh game
		util.clear();
		util.drawBoard(board);
		util.drawShadow(tetro, board, currentX, currentY, currentRotation);
		util.drawShape(tetro, currentX, currentY, currentRotation);
		util.drawNextP(nextTetro);
		if (heldPiece < 7) util.drawHeldP(heldPiece);
		util.drawTop();

 		scoreText = "Score: " + to_string(score);
		levelText = "Level: " + to_string(level);
		util.writeText(scoreText, 10, 10, strlen(scoreText.c_str()) * GRID_SIZE, 40);
		util.writeText(levelText, 10, 60, strlen(levelText.c_str()) * GRID_SIZE, 40);
		util.writeText("Next Piece", BOARD_WIDTH * GRID_SIZE - 15, 60 + TOP_OFFSET + 10, 120, 30);
		util.writeText("Held Piece", BOARD_WIDTH* GRID_SIZE - 15, 60 + TOP_OFFSET * 2.5 + 10, 120, 30);

		util.drawUpdate();
	}
	finalScore = score;
	if (currState != GameState::QUIT) currState = GameState::GAME_OVER;
}

// Main Menu
void menu(Util util)
{
	util.clear();
	util.writeText("Tetris!!!", SCREEN_WIDTH / 8, 30, SCREEN_WIDTH / 1.25, SCREEN_HEIGHT / 10);
	util.writeText("Controls:", SCREEN_WIDTH / 8, 200, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 20);
	util.writeText("Arrow keys to move pieces", SCREEN_WIDTH / 6, 250, SCREEN_WIDTH / 1.25, SCREEN_HEIGHT / 25);
	util.writeText("Upward arrow key to rotate", SCREEN_WIDTH / 6, 300, SCREEN_WIDTH / 1.25, SCREEN_HEIGHT / 25);
	util.writeText("Space to 'hard drop' a piece", SCREEN_WIDTH / 6, 350, SCREEN_WIDTH / 1.25, SCREEN_HEIGHT / 25);
	util.writeText("C to hold a piece", SCREEN_WIDTH / 6, 400, SCREEN_WIDTH / 1.25, SCREEN_HEIGHT / 25);
	util.writeText("M to mute/unmute music", SCREEN_WIDTH / 6, 450, SCREEN_WIDTH / 1.25, SCREEN_HEIGHT / 25);
	util.writeText("Esc to quit the game", SCREEN_WIDTH / 6, 500, SCREEN_WIDTH / 1.25, SCREEN_HEIGHT / 25);
	util.writeText("Press enter to start", SCREEN_WIDTH / 8, 600, SCREEN_WIDTH / 1.25, SCREEN_HEIGHT / 15);
	util.drawUpdate();
	while (currState == GameState::START_MENU)
	{

		SDL_Event e;
		while (SDL_PollEvent(&e) != 0)
		{
			if (e.type == SDL_QUIT)
			{
				currState = GameState::QUIT;
				break;
			}

			if (e.type == SDL_KEYDOWN)
			{
				switch (e.key.keysym.sym)
				{
				case SDLK_RETURN:
					currState = GameState::IN_GAME;
					break;
				case SDLK_m:
					muted = true;
					break;
				case SDLK_ESCAPE:
					currState = GameState::QUIT;
					break;
				}
			}
		}
	}
}

// Game Over
void gameOver(Util util)
{
	Mix_VolumeMusic(0);
	while (currState == GameState::GAME_OVER)
	{
		util.clear();
		util.writeText("GAME OVER", SCREEN_WIDTH / 8, 30, SCREEN_WIDTH / 1.25, SCREEN_HEIGHT / 10);
		string scoreText = "Your Final Score: " + to_string(finalScore);
		util.writeText(scoreText, SCREEN_WIDTH / 4, 200, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 20);
		util.writeText("Press esc to exit", SCREEN_WIDTH / 8, 300, SCREEN_WIDTH / 1.25, SCREEN_HEIGHT / 15);
		util.writeText("Press enter to restart", SCREEN_WIDTH / 8, 400, SCREEN_WIDTH / 1.25, SCREEN_HEIGHT / 15);
		util.drawUpdate();

		SDL_Event e;
		while (SDL_PollEvent(&e) != 0)
		{
			if (e.type == SDL_QUIT)
			{
				currState = GameState::QUIT;
				break;
			}
			if (e.type == SDL_KEYDOWN)
			{
				switch (e.key.keysym.sym)
				{
				case SDLK_RETURN:
					currState = GameState::IN_GAME;
					break;
				case SDLK_m:
					muted = true;
					break;
				case SDLK_ESCAPE:
					currState = GameState::QUIT;
					break;
				}
			}
		}
	}
}

void stateLoop()
{
	Tetromino tetro;
	Board board;
	Util util;

	while (currState != GameState::QUIT)
	{
		switch (currState)
		{
		case GameState::START_MENU:
			menu(util);
			break;
		case GameState::IN_GAME:
			gameLoop(util);
			break;
		case GameState::GAME_OVER:
			gameOver(util);
			break;
		}
	}
	util.destroy();

	SDL_Quit();
	TTF_Quit();
	Mix_Quit();
}


